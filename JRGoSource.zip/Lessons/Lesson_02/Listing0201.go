package main      // main  : identifier
import "fmt"      // "fmt" : identifier
func main() {     // {     : punctuation
   var x int      // int   : identifier
   x = 10         // 10    : integer
   fmt.Println(x) // )     : punctuation
}