package main

import "fmt"

func main() {
   // Display the message Hello World to the user
   fmt.Println("Hello, World!")
}