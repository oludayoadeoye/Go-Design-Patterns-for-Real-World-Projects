// Declare the main package
package main

// Import the fmt package
import "fmt"

// The main function
func main() {
   // Display the message Hello World to the user
   fmt.Println("Hello, World!")
}