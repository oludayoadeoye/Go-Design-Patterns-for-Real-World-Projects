package main

import "fmt" // needed for Println

func main() {
   fmt.Println("Hello, World!") // Display the message Hello World
}