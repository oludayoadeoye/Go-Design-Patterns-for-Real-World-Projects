package main

import "fmt"

func main() {
   var Age int = 10
   var age_15 int = 15
   var _age20 int = 20

   fmt.Println(Age)
   fmt.Println(age_15)
   fmt.Println(_age20)
}