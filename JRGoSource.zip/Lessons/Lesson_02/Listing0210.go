package main

import "fmt"

func main() {
   var ^output string = "Hello world!"
   var 2022 string = "The year is 2022."
   fmt.Println(^output, " ", 2022)
}