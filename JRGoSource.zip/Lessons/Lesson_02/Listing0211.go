package main

import "fmt"

func main() {
   // The following statement will throw an error
   fmt.println("Hello, World!")
}
