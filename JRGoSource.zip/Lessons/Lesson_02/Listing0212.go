package Main

import "fmt"

func main() {
   var mainGreeting string = "Hello world!"
   var year string = "The year is 2022."
   fmt.println(MainGreeting, " ", Year)
}
