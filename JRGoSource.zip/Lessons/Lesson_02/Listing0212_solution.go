package main

import "fmt"

func main() {
   var mainGreeting string = "Hello world!"
   var Year string = "The year is 2022."
   fmt.Println(mainGreeting, " ", Year)
}