// output the text in quotation marks
package main

import "fmt"

func main() {
   fmt.println("Hello, world!")
}