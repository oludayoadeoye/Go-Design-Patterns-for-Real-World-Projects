// display the text in quotation marks to an output block
// without moving any of the existing code to a different line
package main

import "fmt"

func main() {
   Println("Go is fun!") Println("Go is also easy.")
}