// create separate variables for first name and last name
// print each name on a separate line
package main

func main() {
   var 1_Name string = "Rebecca" // first name
   var &_Name string = "Roberts" // last name
   fmt.Println("1_Name")
   fmt.Println("&_Name")
}