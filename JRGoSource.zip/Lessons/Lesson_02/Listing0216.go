// Change this program so that it outputs only the text Go is fun!
// Do not delete any of the existing code
package main

import "fmt"

func main() {
   fmt.Println("Go is fun!")
   fmt.Println("Go is also easy!")
}