// Add one line of code that displays the text in quotation marks to
// an output block without repeating the text in quotation marks.
package main

import "fmt"

func main() {
   var output string = "I love Go!"
}