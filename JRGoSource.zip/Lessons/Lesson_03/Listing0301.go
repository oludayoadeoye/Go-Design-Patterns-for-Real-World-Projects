package main

import "fmt"

func main() {
   var message string = "Hello, World!"
   fmt.Println(message)
}