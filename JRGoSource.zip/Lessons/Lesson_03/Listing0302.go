package main

import "fmt"

func main() {
   // the variable declaration below is invalid due to invalid
   // naming convention
   var 0_email string = "john@john.com"
   fmt.Println(0_email)
}