package main

import "fmt"

func main() {

var message string        // declare the variable
message = "Hello, World!" // assign a value to the variable

fmt.Println(message)
}