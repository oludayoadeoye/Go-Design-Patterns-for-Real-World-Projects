package main

import "fmt"

func main() {
   var message, email string  // declare two string variables
   message = "Hello, World!"  // assign a value to one variable
   email = "john@john.com"    // assign a value to the second variable

   fmt.Println(message)
   fmt.Println(email)
}