package main

import "fmt"

func main() {
   // initialize two string variables in the same statement
   var message, email string = "Hello, World!", "john@john.com"

   fmt.Println(message)
   fmt.Println(email)
}