package main

import "fmt"

func main() {
   // initialize a variable and assign a value in the same statement
   var message string = "Hello, World!"

   fmt.Println(message)
}