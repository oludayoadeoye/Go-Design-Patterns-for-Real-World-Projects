package main

import "fmt"

func main() {
   // dynamic declaration using the := operator
   email := "john@john.com"

   fmt.Println(email)
}