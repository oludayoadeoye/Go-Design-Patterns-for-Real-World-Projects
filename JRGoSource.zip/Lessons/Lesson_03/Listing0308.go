package main

import "fmt"

func main() {
   // dynamic declaration using the := operator
   age := 42

   fmt.Println(age)
}