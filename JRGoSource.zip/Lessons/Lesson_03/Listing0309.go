package main

import "fmt"

func main() {
   var message = "Hello, World!" // initialize with a string value
   email := "john@john.com"      // initialize with a string value

   fmt.Println(message)
   fmt.Println(email)
}