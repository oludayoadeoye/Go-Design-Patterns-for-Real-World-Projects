package main

import "fmt"

func main() {
   message = "Hello, World!"    // missing var
   var email := "john@john.com" // cannot use var and := together

   fmt.Println(message)
   fmt.Println(email)
}