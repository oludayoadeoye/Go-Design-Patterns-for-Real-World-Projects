package main

import "fmt"

func main() {
   var message, year = "Hello, World!", 2022

   fmt.Println(message)
   fmt.Println(year)
}