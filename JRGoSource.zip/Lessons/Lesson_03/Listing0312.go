package main

import "fmt"

func main() {
   // local variable
   var message string = "Hello, World!"

   fmt.Println(message)
}