package main

import "fmt"

// global variable
var message string = "Hello, World!"

func main() {
   // local variable
   var email string = "john@john.com"

   fmt.Println(message)
   fmt.Println(email)
}