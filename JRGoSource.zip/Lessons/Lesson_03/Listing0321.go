package main

import "fmt"

func main() {
   // architecture-independent integers
   var age int8 = 200 // signed 8-bit integer
   fmt.Println("age int8:",age)
}