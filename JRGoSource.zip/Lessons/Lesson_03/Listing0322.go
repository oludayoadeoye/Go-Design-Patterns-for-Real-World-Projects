package main

import "fmt"

func main() {
   var aaa uint = 20; // unsigned implementation-specific data type
   fmt.Println("aaa uint:", aaa)

   var bbb int = -30;
   //signed implementation-specific data type
   fmt.Println("bbb int:", bbb)
}