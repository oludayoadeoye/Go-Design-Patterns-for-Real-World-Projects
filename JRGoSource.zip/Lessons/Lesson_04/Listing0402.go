package main

import "fmt"

func main() {
   var a int = 10
   var b int32 = 20
   var c byte = 15
   var d float32 = 0.05

   // fmt.Println(a + b) // int & int32
   // fmt.Println(b + c) // int32 & byte
   // fmt.Println(a + c) // int & byte
   // fmt.Println(a + d) // int & float32
   // fmt.Println(b * d) // int32 & float32
   // fmt.Println(c / d) // byte & float32
}