package main

import "fmt"

func main() {
   var myBool bool = true
   fmt.Println("myBool =", myBool)

   var anotherBool bool = false
   fmt.Println("anotherBool =", anotherBool)
}