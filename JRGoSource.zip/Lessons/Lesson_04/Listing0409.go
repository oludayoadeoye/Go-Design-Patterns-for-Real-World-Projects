package main

import "fmt"

func main() {
   var n, m int = 2, 10
   a := n < m // assign the result of n < m to a
   fmt.Println("a =", a)
}