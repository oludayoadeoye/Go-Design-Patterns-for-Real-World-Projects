package main

import (
   "fmt"
   "math/rand"
)

func main() {
   fmt.Println(rand.Float32())
   fmt.Println(rand.Float64())
   fmt.Println(rand.Int())
}