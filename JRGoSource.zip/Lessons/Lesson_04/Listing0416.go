package main

import (
   "fmt"
   "math/rand"
)

func main() {
   fmt.Print(rand.Intn(100))
}