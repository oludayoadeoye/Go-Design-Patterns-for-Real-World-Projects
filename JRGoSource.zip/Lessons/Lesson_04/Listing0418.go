// The program should output 0
package main

import "fmt"

func main() {
   // do not change the order in which the numbers and operators appear
   fmt.Println(5 + 3 % 2 * 9)
}