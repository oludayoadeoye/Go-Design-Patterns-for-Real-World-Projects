package main

import "fmt"

func main() {
   var age int8 = 12;
   if (age > 16){
      fmt.Println("This person can open a bank account.") 
   }
}