package main

import "fmt"

func main() {
 var ctr int = 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
 ctr += 1
 fmt.Println(ctr)
}