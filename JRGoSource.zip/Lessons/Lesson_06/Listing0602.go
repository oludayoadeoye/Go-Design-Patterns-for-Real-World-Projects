package main 

import "fmt"

func main() {
   for ctr := 1; ctr <= 10; ctr++ {
      fmt.Println(ctr)
   }
}