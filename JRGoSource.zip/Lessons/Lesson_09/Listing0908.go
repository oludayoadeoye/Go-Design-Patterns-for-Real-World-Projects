package main

import "fmt"

func main() {
   numbers := [...]int {5, 6, 7, 9}
   fmt.Println(numbers)
   fmt.Println(len(numbers))
}
