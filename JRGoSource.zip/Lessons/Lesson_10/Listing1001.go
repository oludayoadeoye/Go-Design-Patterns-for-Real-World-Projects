package main

import "fmt"

func main() {
   var a int = 20 // a stores the value 20
   var b *int     // create a pointer variable b

   fmt.Println(a)
   fmt.Println(b)
}