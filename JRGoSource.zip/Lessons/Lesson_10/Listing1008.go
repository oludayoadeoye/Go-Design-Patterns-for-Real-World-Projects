ppackage main

import "fmt"

func main() {
   var b *int   // create a pointer variable b
   fmt.Println(b)
}
