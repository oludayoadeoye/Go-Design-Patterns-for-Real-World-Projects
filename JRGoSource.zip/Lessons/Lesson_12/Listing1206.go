package main

import (
   "fmt"
)

func main() {
   s := make([]int, 10)
 
   fmt.Println(s)
}
