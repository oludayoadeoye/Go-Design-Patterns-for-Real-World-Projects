type burger struct {
   name string
   price int
   condiments []string
}