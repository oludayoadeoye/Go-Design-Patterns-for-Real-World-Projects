func (b *burger) getName() string {
   return b.name
}