func (b *burger) computePrice() int {
   b.price = burgerPrice
   return b.price
}