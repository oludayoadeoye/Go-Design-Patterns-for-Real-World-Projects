func (b *burger) addCondiment(condiment string) {
    b.condiments = append(b.condiments, condiment)
}