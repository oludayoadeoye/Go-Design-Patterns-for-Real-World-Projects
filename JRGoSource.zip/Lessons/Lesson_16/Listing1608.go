type drink struct {
   name string
   size int
   price int
}