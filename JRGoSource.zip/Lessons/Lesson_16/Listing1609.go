func (d *drink) getName() string {
   return d.name
}
