func (d *drink) getSize() int {
   return d.size
}