func main() {
   var d drink
   d.name = "Sprite"
   d.size = 24
   d.display(true)
}