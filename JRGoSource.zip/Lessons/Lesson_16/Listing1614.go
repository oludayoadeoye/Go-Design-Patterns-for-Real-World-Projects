type side struct {
   name string
   price int
}