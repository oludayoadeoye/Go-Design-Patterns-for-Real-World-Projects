func (s *side) getName() string {
   return s.name
}