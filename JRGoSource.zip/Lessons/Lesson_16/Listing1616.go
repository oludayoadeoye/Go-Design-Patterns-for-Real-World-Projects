func (s *side) computePrice() int {
   s.price = sidePrice
   return s.price
}
