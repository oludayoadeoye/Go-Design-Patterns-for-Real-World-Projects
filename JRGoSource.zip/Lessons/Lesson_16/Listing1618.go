func main() {
   var s side
   s.name = "coleslaw"
   s.display(true)
}