type combo struct {
   name string
   burger burger
   drink drink
   side side
   price int
}