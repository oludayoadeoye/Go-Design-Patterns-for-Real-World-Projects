func (c *combo) getName() string {
   return c.name
}