func main() {
   var c combo
   c.burger = b
   c.side = s
   c.drink = d
   c.display()
}
