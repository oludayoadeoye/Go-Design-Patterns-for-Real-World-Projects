type order struct {
   name string
   price int
   burgers []burger
   drinks []drink
   sides []side
   combos []combo
}