const burgerPrice = 6.00
const sidePrice = 2.00
const comboDiscount = 1.00

var burgerCondiments = []string{"Lettuce", "Tomato", "Onion", "Mayo"}
var drinkTypes = []string{"FANTA", "COKE", "SPRITE", "PEPSI"}
var drinks = map[int]int{12: 1, 16: 2, 24: 3}
var sideTypes = []string{"fries", "coleslaw", "salad"}
var possibleChoices = []string{"b", "s", "d", "c"}