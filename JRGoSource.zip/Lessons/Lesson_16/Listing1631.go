var b = orderBurger()
b.display(true)