package main

import "fmt"

func main() {
   var myChannel chan int
 
   fmt.Println(myChannel)
}