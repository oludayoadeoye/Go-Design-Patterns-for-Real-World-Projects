type Dataset struct {
   filepath string
   reviews []Review
}