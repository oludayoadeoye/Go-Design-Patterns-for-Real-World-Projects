func main() {
   // initialize the dataset
   Accounts = []Account{
       Account{Number: "C45t34534", Balance: "24545.5", Desc: "Checking Account"},
       Account{Number: "S3r53455345", Balance: "444.4", Desc: "Savings Account"},
   }
   handleRequests()
}