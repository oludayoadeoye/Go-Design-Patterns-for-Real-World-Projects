package main

import (
   "fmt"
   "mymodule"
)

func main() {
   fmt.Println(mymodule.RepeatString("Hello", 5))
}